Documentation
=============

.. toctree::
    :maxdepth: 2


.. autosummary::
    :toctree: _autosummary
    :recursive:

    quaos
